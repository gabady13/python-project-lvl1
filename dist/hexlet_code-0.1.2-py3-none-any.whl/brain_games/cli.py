import prompt


def welcome_user():
    prompt.string('May I have your name? ')
