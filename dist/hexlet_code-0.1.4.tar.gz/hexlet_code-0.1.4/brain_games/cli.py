

"""welcome user."""

import prompt


def welcome_user():
    """Welcome user function."""
    prompt.string('May I have your name? ')
