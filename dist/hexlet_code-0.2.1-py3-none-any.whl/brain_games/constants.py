"""Constants of the games."""

from enum import Enum

TYPE_GAMES = Enum('game', 'even,calc,gcd,progression,prime')
