#!/usr/bin/env python

"""welcome user."""


def main():
    """Welcome function."""
    print('Welcome to the Brain Games!')


if __name__ == '__main__':
    main()
